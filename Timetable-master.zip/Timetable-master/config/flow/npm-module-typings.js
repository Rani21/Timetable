/**
 * contains module declarations of modules that needed
 * to be ignored because of errors
 * @flow
 */

declare module 'react-native-keyboard-aware-scroll-view' {
  declare var exports: any;
}
