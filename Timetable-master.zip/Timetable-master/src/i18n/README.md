Template taken from https://github.com/hiaw/rn-translate-template

`I18n.js` requires translation file and moment.js locale file for locale of the device in use.  
To make them available globally, `I18n.js` must be required in the app's entry point.
